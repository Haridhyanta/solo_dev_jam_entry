import enum


class Scene(enum.Enum):
    HOME = enum.auto()
    GAME = enum.auto()
    QUIT = enum.auto()
