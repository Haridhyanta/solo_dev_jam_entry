from typing import Any, Callable, Coroutine
import asyncio

import pygame as pg
from game import game
from scenes import Scene
from game_data import GameData

# import enum

# class Scene(enum.Enum):
#     GAME = enum.auto()
#     QUIT = enum.auto()
 
# class Singleton(type):
#     _instances = {}
#     def __call__(cls, *args, **kwargs):
#         if cls not in cls._instances:
#             cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
#         return cls._instances[cls]
# 
# class GameData(metaclass=Singleton):
#     def __init__(self):
#         pg.init()
#         pg.font.init()
# 
#         WIND_X, WIND_Y = 500, 500
#         self.screen: pg.surface.Surface = pg.display.set_mode((WIND_X, WIND_Y))
#         self.WIND_X, self.WIND_Y = WIND_X, WIND_Y
# 
#         self.clock: pg.time.Clock = pg.time.Clock()
#         self.max_fps: float = 0
# 
#         self.bg_color: tuple[int, int, int] = 0, 0, 0

# async def game() -> Scene:
#     game_data: GameData = GameData()
# 
#     screen: pg.surface.Surface = game_data.screen
#     WIND_X, WIND_Y = game_data.WIND_X, game_data.WIND_Y
#     bg_color: tuple[int, int, int] = game_data.bg_color
# 
#     clock: pg.time.Clock = game_data.clock
#     max_fps: float = game_data.max_fps
#     dt: int = 0
# 
#     while True:
#         dt = clock.tick(max_fps)
#         screen.fill(bg_color)
# 
#         for event in pg.event.get():
#             if event.type == pg.QUIT:
#                 return Scene.QUIT
# 
#         pg.display.update()
#         await asyncio.sleep(0)

scenes_to_func: dict[Scene, Callable[[], Coroutine[Any, Any, Scene]]] = {
    Scene.GAME: game,
}

async def main():
    GameData()
    current_scene: Scene = Scene.GAME

    while current_scene != Scene.QUIT:
        current_scene = await scenes_to_func[current_scene]()
        await asyncio.sleep(0)

    pg.quit()
    
if __name__ == '__main__':
    asyncio.run(main())
